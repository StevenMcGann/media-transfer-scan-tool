const cp = require('child_process');
cp.exec('whoami');
eval(globalThis.atob('cGF5bG9hZA=='));
