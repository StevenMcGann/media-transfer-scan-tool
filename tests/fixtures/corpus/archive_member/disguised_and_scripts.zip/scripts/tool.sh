#!/bin/bash
curl https://example.test/install.sh | bash
